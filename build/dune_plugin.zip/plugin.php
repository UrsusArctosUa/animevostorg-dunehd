<?php

require_once 'lib/default_dune_plugin_fw.php';
require 'animevost_plugin.php';

DefaultDunePluginFw::$plugin_class_name = 'AnimevostPlugin';
